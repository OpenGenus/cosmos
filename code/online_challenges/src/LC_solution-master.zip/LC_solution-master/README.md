# LC_solution
In thie repo i am going to add my LC solutions 
